$(function(){
     //카달로그 클릭 시 팝업
    $("#catalog img").click(function(){
        $("#popup_bg").fadeIn();
    })
    
    
    
    //팝업 닫기 버튼
    $(".close").click(function(){
        $("#popup_bg").fadeOut();
    })
    $(".enter").click(function(){
        $("#popup_bg").fadeOut();
    })
    
    
    
    //메인 메뉴
    $("#gnb>li").on({
        "mouseover": function(){
            $(this).children(".sub_menu").stop().show()
        },
        "mouseout": function(){
            $(this).children(".sub_menu").stop().hide()
        }
    });
    
    
    
    
    //버튼 클릭 슬라이더
    var slider = $("#sbox");
    
    var width = $("#sbox>li").width();
    var length = $("#sbox>li").length;
    slider.width(width*length);
    
    function next(){ //다음 버튼 클릭하면 동작
        $("#sbox").stop(true).animate({left: -width}, 1500, function(){
            $("#sbox>li:eq(0)").appendTo("#sbox");
            $("#sbox").css({left:0});
        });
        var num=$("#sbox>li:first").next().attr("class");
            $(".dot>a").removeClass("on");
            $(".dot>a").eq(num).addClass("on");
        
       }
        $(".next").on("click", next);
        
        function prev(){
            $("#sbox>li:last").prependTo("#sbox");
            $("#sbox").css({left: -width});
            $("#sbox").stop(true).animate({left:0}, 1500);
            
            var num=$("#sbox>li:first").attr("class");
            $(".dot>a").removeClass("on");
            $(".dot>a").eq(num).addClass("on");
        }
        $(".prev").on("click", prev); 
       setInterval(next, 4000);
    
        
    
    
    //tab
    $("#tab_title a").on("click",function(e){
        e.preventDefault();
        $(this).addClass("on").siblings().removeClass("on");
        var index = $(".ch").index(this);
        console.log(index);
        $("#tab_con .con").eq(index).show().siblings().hide();
    })
    $("#tab_menu .ch:eq(0)").click();
    
    
    //공지사항, qna
    $.ajax({
        url: "data1.json",
        dataType: "json",
        success: function(data){
            
            var $ulTag = $("<ul>");
            $.each(data, function(i, o){
                var section = $("<li>").text(o.section);
                var title = $("<span>").text(o.title);
                
                section.append(title);
                
                $ulTag.append(section);
            });
            $("#notice").append($ulTag);
        }
    })
    
    $.ajax({
        url: "data2.json",
        dataType: "json",
        success: function(data){
            
            var $ululTag = $("<ul>");
            $.each(data, function(i, o){
                var sec = $("<li>").text(o.sec);
                var tit = $("<span>").text(o.tit);
                
                sec.append(tit);
                
                $ululTag.append(sec);
            });
            $("#qna").append($ululTag);
        }
    })
     
})